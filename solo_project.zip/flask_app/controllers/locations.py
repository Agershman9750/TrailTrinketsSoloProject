from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.location import Item
from flask_app.models.user import User


@app.route('/market')
def sighting():
    if 'users_id' not in session:
        return redirect('/')
    user = User.get_by_id({"id": session['users_id']})
    if not user:
        return redirect('/user/logout')
    return render_template('market.html', user=user, items=Item.get_all())

@app.route('/new/listing')
def create_item():
    if 'users_id' not in session:
        return redirect('/')
    
    user = User.get_by_id({"id": session['users_id']})
    if not user:
        return redirect('/user/logout')

    return render_template('create.html', user=user)

@app.route('/locations/new/process', methods=['POST'])
def process_item():
    if 'users_id' not in session:
        return redirect('/')
    if not Item.validate_item(request.form):
        return redirect('/market')

    data = {
        'users_id': session['users_id'],
        'type': request.form['type'],
        'brand': request.form['brand'],
        'description': request.form['description'],
        'date_made': request.form['date_made'],
        'amount': request.form['amount'],
        'weight': request.form['weight'],
    }
    Item.save(data)
    return redirect('/market')

@app.route('/show/<int:id>')
def view_item(id):
    if 'users_id' not in session:
        return redirect('/')

    user = User.get_by_id({'id': session['users_id']})  
    if not user:
        return redirect('/user/logout')

    item = Item.get_by_id({'id': id})  
    if not item:
        return redirect('/market')

    return render_template('view.html', item=item, user=user)

@app.route('/edit/<int:id>')
def edit_item(id):
    if 'users_id' not in session:
        return redirect('/')

    user = User.get_by_id({'id': session['users_id']})  
    if not user:
        return redirect('/')

    item = Item.get_by_id({'id': id}) 
    if not Item:
        return redirect('/market')

    return render_template('edit.html', item=item, user=user)

@app.route('/edit/process/<int:id>', methods=['POST'])
def process_edit_item(id):
    if 'users_id' not in session:
        return redirect('/')
    if not Item.validate_item(request.form):
        return redirect(f'/edit/{id}')

    data = {
        'id': id,
        'type': request.form['type'],
        'brand': request.form['brand'],
        'description': request.form['description'],
        'date_made': request.form['date_made'],
        'amount': request.form['amount'],
        'weight': request.form['weight'],
    }
    Item.update(data)
    return redirect('/market')

@app.route('/destroy/<int:id>')
def destroy_item(id):
    if 'users_id' not in session:
        return redirect('/')

    Item.destroy({'id': id})
    return redirect('/market')

@app.route('/email/<int:id>')
def reveal_email(id):
    if 'users_id' not in session:
        return redirect('/')

    user = User.get_by_id({'id': session['users_id']})  
    if not user:
        return redirect('/user/logout')

    item = Item.get_by_id({'id': id})  
    if not item:
        return redirect('/market')

    return render_template('view.html', item=item, user=user, show_email=True)
