from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.user import User

@app.route('/')
def login():
    if 'users_id' in session:
        return redirect('/market')
    return render_template('home.html')

@app.route('/login')
def login2():
    if 'users_id' in session:
        return redirect('/market')
    return render_template('index.html')


@app.route('/user/login/process', methods=['POST'])
def login_success():
    user = User.validate_login(request.form)
    if not user:
        return redirect('/login')
    session['users_id'] = user.id
    return redirect('/market')


@app.route('/user/register/process', methods=['POST'])
def register_success():
    if not User.validate_reg(request.form):
        return redirect('/login')

    user_id = User.save(request.form)
    session['users_id'] = user_id
    return redirect('/market')


@app.route('/user/logout')
def logout():
    if 'users_id' in session:
        session.pop('users_id')
    return redirect('/')

@app.route('/food')
def food():
    if 'users_id' in session:
        return redirect('/food')
    return render_template('food.html')

@app.route('/water')
def water():
    if 'users_id' in session:
        return redirect('/water')
    return render_template('water.html')

@app.route('/weight')
def weight():
    if 'users_id' in session:
        return redirect('/weight')
    return render_template('weight.html')

@app.route('/calculate/calories', methods=['POST'])
def calculate_calories():
    distance = float(request.form.get('distance'))
    calories_burned = distance * 511

    return render_template('food.html', distance=distance, calories_burned=calories_burned)

@app.route('/calculate/water', methods=['POST'])
def calculate_water():
    hour = float(request.form.get('water'))
    water_used = hour * 16

    return render_template('water.html', hour=hour, water_used=water_used)

@app.route('/calculate/weight', methods=['POST'])
def calculate_weight():
    weight = float(request.form.get('weight'))
    weight_percent_10 = weight * 0.1
    weight_percent_20 = weight * 0.2

    return render_template('weight.html', weight_value=weight, weight_percent_10=weight_percent_10, weight_percent_20=weight_percent_20)